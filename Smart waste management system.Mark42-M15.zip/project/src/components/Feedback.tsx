import React, { useState } from 'react';
import { MessageSquare, ThumbsUp } from 'lucide-react';

function Feedback() {
  const [feedback, setFeedback] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle feedback submission
    setSubmitted(true);
    setFeedback('');
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">User Feedback</h2>

      {submitted ? (
        <div className="bg-green-50 p-6 rounded-lg flex items-center gap-3">
          <ThumbsUp className="h-6 w-6 text-green-600" />
          <p className="text-green-600">Thank you for your feedback!</p>
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-sm p-6">
          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <label className="block text-gray-700 font-medium mb-2">
                Share your thoughts or suggestions
              </label>
              <textarea
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-green-500"
                rows={5}
                required
              ></textarea>
            </div>
            <button
              type="submit"
              className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 transition-colors"
            >
              Submit Feedback
            </button>
          </form>
        </div>
      )}
    </div>
  );
}

export default Feedback