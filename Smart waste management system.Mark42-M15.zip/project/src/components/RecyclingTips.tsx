import React from 'react';
import { Recycle, Lightbulb, Battery, Smartphone, Box, Leaf } from 'lucide-react';

function RecyclingTips() {
  const tips = [
    {
      title: 'Proper Waste Segregation',
      description: 'Separate your waste into different categories: organic, recyclable, and hazardous waste.',
      icon: <Recycle className="h-6 w-6 text-green-600" />
    },
    {
      title: 'Composting',
      description: 'Convert your kitchen waste into valuable compost for your garden.',
      icon: <Leaf className="h-6 w-6 text-green-600" />
    },
    {
      title: 'E-Waste Management',
      description: 'Never mix electronic waste with regular trash. Use authorized e-waste collection centers.',
      icon: <Smartphone className="h-6 w-6 text-green-600" />
    },
    {
      title: 'Battery Disposal',
      description: 'Collect used batteries separately and dispose of them at designated collection points.',
      icon: <Battery className="h-6 w-6 text-green-600" />
    },
    {
      title: 'Packaging Reduction',
      description: 'Choose products with minimal packaging and reuse packaging materials when possible.',
      icon: <Box className="h-6 w-6 text-green-600" />
    },
    {
      title: 'Energy Conservation',
      description: 'Turn off electronic devices when not in use and dispose of energy-efficient appliances properly.',
      icon: <Lightbulb className="h-6 w-6 text-green-600" />
    }
  ];

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Recycling Tips</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {tips.map((tip, index) => (
          <div key={index} className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-start gap-4">
              {tip.icon}
              <div>
                <h3 className="font-semibold text-lg mb-2">{tip.title}</h3>
                <p className="text-gray-600">{tip.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default RecyclingTips