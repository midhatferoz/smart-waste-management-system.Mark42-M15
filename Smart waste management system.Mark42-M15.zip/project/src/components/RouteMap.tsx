import React from 'react';
import { MapPin } from 'lucide-react';

function RouteMap() {
  const cities = [
    { name: 'Mumbai', urgency: 'high', waste: '7,000 tons/day' },
    { name: 'Delhi', urgency: 'high', waste: '9,500 tons/day' },
    { name: 'Bangalore', urgency: 'medium', waste: '5,000 tons/day' },
    { name: 'Chennai', urgency: 'medium', waste: '4,500 tons/day' },
    { name: 'Kolkata', urgency: 'high', waste: '4,000 tons/day' }
  ];

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Smart Waste Management Route Map</h2>
      
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Map Section */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <div 
            className="w-full h-[400px] rounded-lg bg-cover bg-center relative"
            style={{
              backgroundImage: 'linear-gradient(rgba(0, 0, 0, 0.2), rgba(0, 0, 0, 0.2)), url("https://www.mapsofindia.com/maps/delhi/delhi-map-large.gif ")'
            }}
          >
            {/* Map Markers */}
            <div className="absolute top-1/4 left-1/3">
              <MapPin className="h-6 w-6 text-red-500" />
            </div>
            <div className="absolute top-1/3 left-1/2">
              <MapPin className="h-6 w-6 text-red-500" />
            </div>
            <div className="absolute bottom-1/3 right-1/3">
              <MapPin className="h-6 w-6 text-orange-500" />
            </div>
          </div>
        </div>

        {/* Cities List */}
        <div className="bg-white rounded-lg shadow-sm p-6">
          <h3 className="text-xl font-semibold mb-4">Priority Cities</h3>
          <div className="space-y-4">
            {cities.map((city) => (
              <div key={city.name} className="border-b pb-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-semibold">{city.name}</h4>
                    <p className="text-sm text-gray-600">Daily Waste: {city.waste}</p>
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-sm ${
                      city.urgency === 'high'
                        ? 'bg-red-100 text-red-800'
                        : 'bg-orange-100 text-orange-800'
                    }`}
                  >
                    {city.urgency === 'high' ? 'High Priority' : 'Medium Priority'}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default RouteMap