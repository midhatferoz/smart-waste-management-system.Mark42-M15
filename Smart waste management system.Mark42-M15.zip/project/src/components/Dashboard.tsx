import React from 'react';
import { Trash2, AlertTriangle, Truck, Battery } from 'lucide-react';

function Dashboard() {
  const bins = [
    { id: 1, location: 'Sector 1, Block A', fillLevel: 85, battery: 90 },
    { id: 2, location: 'Sector 2, Market', fillLevel: 45, battery: 75 },
    { id: 3, location: 'Sector 3, Park', fillLevel: 90, battery: 85 },
    { id: 4, location: 'Sector 4, Mall', fillLevel: 30, battery: 95 },
  ];

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Smart Bin Monitoring Dashboard</h2>
      
      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500">Total Bins</p>
              <h3 className="text-2xl font-bold">24</h3>
            </div>
            <Trash2 className="h-8 w-8 text-green-600" />
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500">Critical Alerts</p>
              <h3 className="text-2xl font-bold">3</h3>
            </div>
            <AlertTriangle className="h-8 w-8 text-orange-500" />
          </div>
        </div>
        
        <div className="bg-white p-6 rounded-lg shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-gray-500">Active Routes</p>
              <h3 className="text-2xl font-bold">5</h3>
            </div>
            <Truck className="h-8 w-8 text-blue-600" />
          </div>
        </div>
      </div>

      {/* Bins List */}
      <div className="bg-white rounded-lg shadow-sm">
        <div className="p-6">
          <h3 className="text-xl font-semibold mb-4">Smart Bins Status</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="text-left border-b">
                  <th className="pb-3">Location</th>
                  <th className="pb-3">Fill Level</th>
                  <th className="pb-3">Battery</th>
                  <th className="pb-3">Status</th>
                </tr>
              </thead>
              <tbody>
                {bins.map((bin) => (
                  <tr key={bin.id} className="border-b">
                    <td className="py-3">{bin.location}</td>
                    <td className="py-3">
                      <div className="flex items-center">
                        <div className="w-24 bg-gray-200 rounded-full h-2.5">
                          <div
                            className={`h-2.5 rounded-full ${
                              bin.fillLevel > 80 ? 'bg-red-500' : 
                              bin.fillLevel > 60 ? 'bg-orange-500' : 'bg-green-500'
                            }`}
                            style={{ width: `${bin.fillLevel}%` }}
                          ></div>
                        </div>
                        <span className="ml-2">{bin.fillLevel}%</span>
                      </div>
                    </td>
                    <td className="py-3">
                      <div className="flex items-center">
                        <Battery className="h-4 w-4 mr-1" />
                        {bin.battery}%
                      </div>
                    </td>
                    <td className="py-3">
                      <span
                        className={`px-2 py-1 rounded-full text-sm ${
                          bin.fillLevel > 80
                            ? 'bg-red-100 text-red-800'
                            : 'bg-green-100 text-green-800'
                        }`}
                      >
                        {bin.fillLevel > 80 ? 'Critical' : 'Normal'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard