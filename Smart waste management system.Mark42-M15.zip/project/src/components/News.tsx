import React from 'react';
import { Newspaper } from 'lucide-react';

function News() {
  const news = [
    {
      title: 'AI-Powered Waste Sorting System Launches in Smart Cities',
      date: '2025-03-15',
      description: 'New technology uses machine learning to automatically sort waste with 99% accuracy.',
      category: 'Technology'
    },
    {
      title: 'Smart Bins Reduce Collection Costs by 30%',
      date: '2025-03-10',
      description: 'Implementation of IoT sensors in waste bins leads to significant cost savings.',
      category: 'Innovation'
    }
    // Add more news items
  ];

  return (
    <div>
      <h2 className="text-2xl font-bold mb-6">Sustainability News</h2>

      <div className="space-y-6">
        {news.map((item, index) => (
          <div key={index} className="bg-white rounded-lg shadow-sm p-6">
            <div className="flex items-start gap-4">
              <Newspaper className="h-6 w-6 text-green-600 flex-shrink-0" />
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <h3 className="font-semibold text-lg">{item.title}</h3>
                  <span className="px-2 py-1 rounded-full bg-green-100 text-green-800 text-sm">
                    {item.category}
                  </span>
                </div>
                <p className="text-sm text-gray-500 mb-2">{item.date}</p>
                <p className="text-gray-600">{item.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default News