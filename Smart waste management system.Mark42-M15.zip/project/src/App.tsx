import React, { useState } from 'react';
import { MapPin, Trash2, BarChart2, Route, MessageSquare, Recycle, Newspaper, LogOut } from 'lucide-react';
import Login from './components/Login';
import Dashboard from './components/Dashboard';
import RouteMap from './components/RouteMap';
import Feedback from './components/Feedback';
import RecyclingTips from './components/RecyclingTips';
import News from './components/News';

function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [activeTab, setActiveTab] = useState('dashboard');

  const handleLogin = (credentials: { email: string; password: string }) => {
    // In a real app, implement proper authentication
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
  };

  if (!isLoggedIn) {
    return <Login onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <div className="w-64 bg-white shadow-lg">
        <div className="p-6">
          <h1 className="text-2xl font-bold text-green-600 flex items-center gap-2">
            <Trash2 className="h-6 w-6" />
            SmartWaste
          </h1>
        </div>
        <nav className="mt-6">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`w-full flex items-center gap-2 px-6 py-3 ${
              activeTab === 'dashboard' ? 'bg-green-50 text-green-600' : 'text-gray-600'
            }`}
          >
            <BarChart2 className="h-5 w-5" />
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab('routes')}
            className={`w-full flex items-center gap-2 px-6 py-3 ${
              activeTab === 'routes' ? 'bg-green-50 text-green-600' : 'text-gray-600'
            }`}
          >
            <Route className="h-5 w-5" />
            Route Map
          </button>
          <button
            onClick={() => setActiveTab('feedback')}
            className={`w-full flex items-center gap-2 px-6 py-3 ${
              activeTab === 'feedback' ? 'bg-green-50 text-green-600' : 'text-gray-600'
            }`}
          >
            <MessageSquare className="h-5 w-5" />
            Feedback
          </button>
          <button
            onClick={() => setActiveTab('tips')}
            className={`w-full flex items-center gap-2 px-6 py-3 ${
              activeTab === 'tips' ? 'bg-green-50 text-green-600' : 'text-gray-600'
            }`}
          >
            <Recycle className="h-5 w-5" />
            Recycling Tips
          </button>
          <button
            onClick={() => setActiveTab('news')}
            className={`w-full flex items-center gap-2 px-6 py-3 ${
              activeTab === 'news' ? 'bg-green-50 text-green-600' : 'text-gray-600'
            }`}
          >
            <Newspaper className="h-5 w-5" />
            News
          </button>
        </nav>
        <div className="absolute bottom-0 w-64 p-6">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-2 px-4 py-2 text-red-600 hover:bg-red-50 rounded-lg"
          >
            <LogOut className="h-5 w-5" />
            Logout
          </button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 p-8">
        {activeTab === 'dashboard' && <Dashboard />}
        {activeTab === 'routes' && <RouteMap />}
        {activeTab === 'feedback' && <Feedback />}
        {activeTab === 'tips' && <RecyclingTips />}
        {activeTab === 'news' && <News />}
      </div>
    </div>
  );
}

export default App;